﻿namespace GestionCasos
{
    public class CasosFalsos
    {

        public string Caso { get; set; }
        public string Fecha { get; set; }
        public int Codigo { get; set; }
        public string Junta { get; set; }
        public int Circuito { get; set; }
        public string Recepcion { get; set; }
        public string Persona { get; set; }
        public string Comentario { get; set; }
        public string Estado { get; set; }
    }
}
