﻿using Entidades;
using System;
using System.Collections.Generic;
using Utilidades.Interfaces;

namespace Negocios
{
    //Plantilla
    public class TipoInstitucionNegocio : ICrud<t_Tipo_Institucion>
    {
        public bool eliminar(t_Tipo_Institucion e)
        {
            throw new NotImplementedException();
        }

        public bool guardar(t_Tipo_Institucion e)
        {
            throw new NotImplementedException();
        }

        public bool modificar(t_Tipo_Institucion e)
        {
            throw new NotImplementedException();
        }

        public t_Tipo_Institucion obtenerPorId(t_Tipo_Institucion e)
        {
            throw new NotImplementedException();
        }

        public IEnumerable<t_Tipo_Institucion> obtenerTodo(t_Tipo_Institucion e)
        {
            throw new NotImplementedException();
        }
    }
}
