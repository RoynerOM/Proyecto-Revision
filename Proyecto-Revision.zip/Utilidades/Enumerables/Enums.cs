﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilidades.Enumerables
{
    public class Enums
    {
        public enum MedioReceptivo
        {
            Correo,
            Oficina,
            Mensajero,
            Whatsapp
        }

        public enum Estado
        {
            activo ,
            inactivo
        }

    }
}
